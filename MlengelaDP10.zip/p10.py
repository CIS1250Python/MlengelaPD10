# ----------------------------------------------------------------------------
# MlengelaDP4
# 
# Programmer: Daudi Mlengela
# 
# Email: mlengelad@gmail.com
# 
# Purpose: Find the closest point to the point supplied by the user
# ----------------------------------------------------------------------------

from geopoint import GeoPoint
import tkinter as tk
from tkinter import *
import tkinter.messagebox
import sys

# -----------------------
# getResults
# -----------------------

def getResults():

   # -----------------------
   # points file name
   # -----------------------

   pointsFileValue = pointsFileText.get().strip()

   if(pointsFileValue == ""):
      tk.messagebox.showinfo("Error", "No value supplied for 'Points File'")
      return

   # -----------------------
   # latitude
   # -----------------------

   latitudeValue = latitudeText.get().strip()

   if(latitudeValue == ""):
      tk.messagebox.showinfo("Error", "No value supplied for 'Latitude'")
      return

   try:
      latitudeValue = float(latitudeValue)

   except:
      tk.messagebox.showinfo("Error", "Invalid value supplied for 'Latitude'")
      return

   # -----------------------
   # longitude
   # -----------------------

   longitudeValue = longitudeText.get().strip()

   if(longitudeValue == ""):
      tk.messagebox.showinfo("Error", "No value supplied for 'Longitude'")
      return

   try:
      longitudeValue = float(longitudeValue)

   except:
      tk.messagebox.showinfo("Error", "Invalid value supplied for 'Longitude'")
      return

   # -----------------------
   # description
   # -----------------------

   descriptionValue = descriptionText.get().strip()

   if(descriptionValue == ""):
      tk.messagebox.showinfo("Error", "No value supplied for 'Description'")
      return

   # -----------------------
   # Load points file
   # -----------------------

   pointsList = []

   try:

      with open(pointsFileValue) as file:
         for line in file:
            values = line.split(",")

            latitude    = float(values[0].strip())
            longitude   = float(values[1].strip())
            description = values[2].strip()

            pointsList.append(GeoPoint(latitude, longitude, description))

   except:

      tk.messagebox.showinfo("Error", "Could not open: " + pointsFileValue)
      return

   # -----------------------
   # Find closest entry
   # -----------------------

   thePoint    = GeoPoint(latitudeValue, longitudeValue, descriptionValue)
   minDistance = 0
   minEntry    = None

   for entry in pointsList:
      distance = entry.CalcDistance(thePoint)
      if minDistance == 0 or distance < minDistance:
         minDistance = distance
         minEntry    = entry

   results = "You are closest to {0}, which is located at ({1})".format(minEntry.description,
      minEntry.point)

   resultsText.set(results)

# -----------------------
# quit
# -----------------------

def quit():
   sys.exit()

# -----------------------
# Script Begins Here
# -----------------------

width   = 400
height  = 350
margin  = 30
yValue  = 50
xCenter = width // 2

parent = tk.Tk()
parent.title("MlengelaPD10")
parent.geometry("{0}x{1}".format(width, height))

pointsFileText   = tk.StringVar()
latitudeText     = tk.StringVar()
longitudeText    = tk.StringVar()
descriptionText  = tk.StringVar()
resultsText      = tk.StringVar()
      
pointsFile      = tk.Label(parent, text = "Points File").place(x = margin, y = yValue)
pointsFileEntry = tk.Entry(parent, textvariable = pointsFileText).place(x = xCenter, y = yValue)
yValue += 40

latitude      = tk.Label(parent, text = "Latitude").place(x = margin, y = yValue)
latitudeEntry = tk.Entry(parent, textvariable = latitudeText).place(x = xCenter, y = yValue)
yValue += 40

longitude      = tk.Label(parent, text = "Longitude").place(x = margin, y = yValue)
longitudeEntry = tk.Entry(parent, textvariable = longitudeText).place(x = xCenter, y = yValue)
yValue += 40

description      = tk.Label(parent, text = "Description").place(x = margin, y = yValue)
descriptionEntry = tk.Entry(parent, textvariable = descriptionText).place(x = xCenter, y = yValue)
yValue += 60

results      = tk.Label(parent, text = "Results").place(x = margin, y = yValue)
yValue += 20
resultsEntry = tk.Entry(parent, textvariable = resultsText, width = 50).place(x = margin, y = yValue)

yValue += 60

tk.Button(parent, text = "Calculate Results", command = getResults).place(x = width // 3, y = yValue)
tk.Button(parent, text = "Quit",   command = quit).place(x = (2 * width // 3), y = yValue)

parent.mainloop()
