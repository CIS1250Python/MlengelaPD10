# ----------------------------------------------------------------------------
# MlengelaDP10
# Programmer: Daudi Mlengela
# Email: dmlengela@cn.edu
# Purpose: Find the closest point to the point supplied by the user
# ----------------------------------------------------------------------------
import math

# ---------------------
# GeoPoint
# ---------------------

class GeoPoint:

   R = 6371000

   def __init__(self, lat = 0, lon = 0, description = 'TBD'):
      self.lat = lat
      self.lon = lon
      self._description = description

   def __str__(self):
      return("{{ description: {0}, latitude: {1}, longitude: {2} }}".format(
         self.description, self.lat, self.lon))

   def SetPoint(self, point):
      self.lat = point[0]
      self.lon = point[1]

   def GetPoint(self):
      return([ self.lat, self.lon ])

   def SetDescription(self, description):
      self._description = description

   def GetDescription(self):
      return(self._description)

   point       = property(GetPoint, SetPoint)
   description = property(GetDescription, SetDescription)

   def CalcDistance(self, point):

      r1 = math.radians(self.lat)
      r2 = math.radians(point.lat)

      a = math.sin(math.radians(point.lat - self.lat) / 2.0) ** 2 + \
          math.cos(r1) * math.cos(r2)                    * \
          math.sin(math.radians(point.lon - self.lon) / 2.0) ** 2

      c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

      meters = GeoPoint.R * c

      return(meters / 1000.0)

